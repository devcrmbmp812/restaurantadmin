var config = {
    apiKey: "AIzaSyB7VBkAuGDMtdlenkpf7YGmNCrtv4wgLPU",
    authDomain: "pizzaandroidapp.firebaseapp.com",
    databaseURL: "https://pizzaandroidapp.firebaseio.com",
    projectId: "pizzaandroidapp",
    storageBucket: "pizzaandroidapp.appspot.com",
    messagingSenderId: "456330711525"
};
firebase.initializeApp(config);